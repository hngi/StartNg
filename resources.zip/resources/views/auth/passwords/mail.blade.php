

<p>Click here {{url('resetpassword/'.$total['email'].'/'.$total['code'])}} to reset your email</p>